# Historical verification is not included in this preview

This path is a package-only notice so links in the preserved development plans continue to resolve. It does not reproduce or replace the canonical historical verification report.

The public source preview deliberately omits the original verification JSON, command logs, binary hashes, source-manifest reports, screenshots, raw environment details, and parent upstream audit artifacts. Those historical records described bounded Linux development scenarios, not Windows/macOS support, named-client certification, comparative performance, or scale readiness.

The five planning documents and desktop README retain their historical wording. In this archive, phrases such as “included verification,” “this checkout has compiled,” and references to the foundation archive or parent audit must be read as statements about the original development snapshot. No build or product tests were run to create this source ZIP.

The source of the core module tests and Python/native/browser harnesses is included, together with the required source build inputs. See the [public quickstart](../README.md) for instructions and [PREVIEW-NOTICE.md](../PREVIEW-NOTICE.md) for exclusions, preservation rules, and checksums. Running those harnesses in a new environment produces separate evidence; their presence is not a passing result.
