# Devagotchi — Linux source preview

Devagotchi is a local desktop bridge under development. This source preview contains a Linux command broker, an MCP stdio adapter, and a native Tauri inspector. The broker owns execution and a SQLite operation journal independently of the adapter and inspector.

**This is Linux development source, version 0.1.0.** It is not a signed release or an installer. Windows and macOS execution providers and distribution are pending. No project license has been selected in the provided source; this archive does not add one or make an open-source-license claim.

Read [PREVIEW-NOTICE.md](PREVIEW-NOTICE.md) for the exact package boundary, historical-document limitations, and integrity checks.

## What is implemented

- An independently launched, per-user Linux broker using a private Unix socket and a local SQLite journal.
- Exact executable and argument-vector execution, operator-configured workspace and executable grants, bounded output retention, an execution deadline, and explicit cancellation.
- Durable operation IDs and idempotency keys; a conflicting retry fails instead of admitting another command under that key.
- Four local MCP tools: `operation_start`, `operation_get`, `operation_read`, and `operation_cancel`.
- A native inspector showing retained activity, operation details, output, connection failures, and cancellation state. It connects to an existing broker and does not launch commands itself.
- Canonical Rust contracts, generated JSON Schema and TypeScript, and the source of the development test harnesses.

Graph execution, trusted-device mesh execution, an authenticated runtime HTTP API, filesystem/search/edit tools, PTYs, and automatic client setup are not implemented in this snapshot. The planning documents describe their proposed contracts and gates. A public documentation API or reference MCP service is separate from this local executable adapter and cannot be used to run these workstation commands. The website source and its public reference service are not included in this ZIP.

## Prerequisites

Use Linux with `/proc`, Unix-domain sockets, and a native compiler/linker toolchain. The checked-in `rust-toolchain.toml` pins Rust **1.99.1**. A Rust installation with rustup can obtain that toolchain. Cargo must be able to obtain the locked dependencies, or use an already populated cache. SQLite is built through the bundled `rusqlite` dependency.

For the optional desktop inspector, also install Node **20.19+ on the 20.x line, or 22.12+**, npm, and the Linux native dependencies for Tauri: GTK 3 and WebKitGTK 4.1 development libraries, `pkg-config`, and a native build toolchain. See the [official Tauri prerequisites](https://v2.tauri.app/start/prerequisites/) for distribution-specific packages. The desktop's npm and native Cargo lockfiles are included.

The commands below are build and setup instructions. Packaging this preview did not run them or establish a new build or test result.

## 1. Check and extract the archive

With the ZIP and its companion checksum file in the same directory:

```bash
sha256sum -c devagotchi-linux-source-preview.sha256
unzip devagotchi-linux-source-preview.zip
cd devagotchi
sha256sum -c FILE-MANIFEST.sha256
```

The archive has one top-level `devagotchi/` directory. The internal manifest covers every file except itself. Checksums provide integrity comparison, not a signed release attestation.

## 2. Build the local broker and adapter

From the extracted `devagotchi/` directory:

```bash
cargo build --locked --bins
```

With the default Cargo target directory, the executables are `target/debug/bridge-broker` and `target/debug/bridge-mcp`. If you set `CARGO_TARGET_DIR`, use that target directory instead.

## 3. Configure and start the broker

Copy `config/broker.example.json` to a location you control, such as an absolute path ending in `broker.json`. Replace every placeholder. The workspace must exist. Executable grants must name the exact canonical absolute executable paths you intend to authorize.

For a small first run, the following authorizes only the indicated `printf` executable. Confirm its actual canonical path on your machine; `/usr/bin/printf` is an example, not a path-discovery mechanism.

```json
{
  "workspace": "/absolute/path/to/workspace",
  "allowed_executables": ["/usr/bin/printf"],
  "output_limit_bytes": 262144,
  "max_operations": 64,
  "max_concurrent": 4
}
```

Choose an absolute state-directory path whose parent already exists. The broker creates its state directory privately if absent. An existing state directory must belong to your user and have mode `0700`; symlink path components are rejected. Use a short enough path for a Unix socket. Keep the configuration and state under your control.

Run the broker in its own terminal or independently managed process:

```bash
./target/debug/bridge-broker \
  --state-dir /absolute/private/state/devagotchi \
  --config /absolute/path/broker.json
```

The resulting endpoint is `/absolute/private/state/devagotchi/broker.sock`. The CLI also supports `--help`. A second broker cannot own the same state directory concurrently.

The current `max_operations` limit counts all retained operations, including completed ones; this is finite development storage, not automatic history rotation. `max_concurrent` limits active operations. Output retention is bounded per operation, but the preview does not claim a physical SQLite disk quota. Retry identity includes the broker configuration, including limits; do not expect an old idempotency key to replay after changing that configuration. Do not delete a journal as a transparent retry reset: deleting retry evidence can permit work to be admitted again.

## 4. Connect a local MCP client

For a client that accepts the conventional `mcpServers` configuration and supports local stdio servers, adapt this entry to your absolute paths:

```json
{
  "mcpServers": {
    "devagotchi": {
      "command": "/absolute/path/to/devagotchi/target/debug/bridge-mcp",
      "args": [
        "--socket",
        "/absolute/private/state/devagotchi/broker.sock"
      ]
    }
  }
}
```

Each MCP host has its own configuration format and support policy. This example does not certify a named host. The adapter requires an already running broker; it does not create one or expand its grants. Its CLI is `bridge-mcp --socket ABS_PATH`, with `--help` also available.

These are the exact current **tool argument objects**, not raw JSON-RPC envelopes. Use the same executable and workspace values you configured above.

`operation_start`:

```json
{
  "idempotency_key": "preview-hello-001",
  "executable": "/usr/bin/printf",
  "args": ["%s\n", "Hello from Devagotchi"],
  "cwd": "/absolute/path/to/workspace",
  "deadline_ms": 5000
}
```

The result contains `operation.operation_id` and `replayed`. Replace `RETURNED_OPERATION_ID` below with that returned ID.

`operation_get`:

```json
{"operation_id": "RETURNED_OPERATION_ID"}
```

`operation_read`:

```json
{"operation_id": "RETURNED_OPERATION_ID", "cursor": 0, "max_bytes": 16384}
```

`operation_cancel`:

```json
{"operation_id": "RETURNED_OPERATION_ID"}
```

The execution deadline is required and must be 1–300,000 milliseconds. It is independent of a client's wait timeout. Reading starts at cursor zero; use the returned `next_cursor` for later reads and inspect gap/completeness fields. Cancellation requests an outcome that the broker observes; receiving a request is not proof that every descendant stopped. The short `printf` operation may have completed before a cancellation call arrives.

After a lost response, repeat the original start request with the same key and inputs to reconcile it. A new key authorizes another operation. Disconnecting or cancelling an MCP wait does not cancel the broker-owned operation; use `operation_cancel` when cancellation is intended.

## 5. Build and open the native inspector

From the project root:

```bash
cd apps/desktop
npm ci
npm run build
cargo build --locked --manifest-path src-tauri/Cargo.toml --features custom-protocol
./src-tauri/target/debug/devagotchi --socket /absolute/private/state/devagotchi/broker.sock
```

Use the corresponding `debug/devagotchi` path if `CARGO_TARGET_DIR` is set. The `custom-protocol` feature embeds the built assets for a standalone native run. A normal browser running the frontend cannot connect to the broker and displays the missing-native-host state. The inspector can also take its socket from `DEVAGOTCHI_SOCKET`; see [desktop instructions](apps/desktop/README.md).

Closing the inspector leaves broker-owned commands running. Stopping the broker itself requests bounded cancellation and is a different action. The inspector is not a tray/service installer, a grant editor, or an execution console.

## Contracts, harnesses, and plans

The current runtime schema is `schemas/broker-contracts.schema.json`. The source of truth is `src/contracts.rs`; desktop types are generated into `apps/desktop/src/generated/contracts.ts`. From the project root, after a Cargo build has fetched the locked Rust dependencies and `npm ci` has installed desktop dependencies:

```bash
node scripts/generate-contracts.cjs --check
```

The generator invokes Cargo with `--offline`. Run it without `--check` only when deliberately regenerating the schema and TypeScript after a contract change.

Core module checks are available through `cargo test --locked --lib`. Process/protocol/boundary/native UI harnesses are under `tests/`; their `--help` describes binary paths and output options. The native UI harness needs additional Tauri WebDriver, WebKitWebDriver, Xvfb, and D-Bus setup. Optional Chromium fixture code lives in `apps/desktop/tests/ui/` and needs Playwright plus a matching Chromium installation. Harness source is included; no historical test reports or new test results are included in this preview.

- [Architecture and growth plan](docs/product-and-platform-plan.md)
- [Performance and workstation experience specification](docs/performance-and-experience-spec.md)
- [Implementation guide](docs/implementation-guide.md)
- [Task graph and mesh contract proposal](docs/task-graph-and-mesh-contract.md)
- [Desktop Commander user evidence](docs/desktop-commander-user-evidence.md)

These planning documents are preserved from the development snapshot. Their archive hashes, historical verification statements, repository-access observations, and publication status refer to that work, not to a fresh public release audit. Their numeric performance budgets are proposed acceptance criteria, not measured results. See [the evidence omission notice](verification/README.md).

## Execution and trust boundary

The broker admits only configured executables and working directories within the configured workspace, but a grant is **not an OS sandbox**. A permitted executable still runs with your OS user's authority; granting a shell or interpreter can authorize broad behavior. The broker uses exact argv, clears the inherited environment, closes stdin, and captures separate stdout/stderr pipes. It does not provide an interactive terminal.

Local socket access is restricted to the same OS user. This snapshot does not distinguish individual MCP clients within that user account. Arguments and command output can contain secrets; they are recorded locally, and an attached client can send information onward under its own behavior.

Linux cancellation supervision applies to the inherited process group. A descendant that creates a new session or otherwise escapes that group is outside the claimed scope. After an unclean restart, unsettled operations are reported with uncertain outcomes instead of being automatically re-executed. These are bounded implementation guarantees, not a claim of general process containment or comprehensive audit coverage.
