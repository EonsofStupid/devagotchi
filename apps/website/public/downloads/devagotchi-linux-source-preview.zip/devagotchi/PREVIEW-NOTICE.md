# Source preview notice

Package date: 2026-10-17 UTC. Product version in the supplied manifests: 0.1.0.

## Distribution status

This archive is a Linux-only development source preview of the supplied Devagotchi snapshot. It is not a signed, notarized, packaged, cross-platform, or production-readiness release. No Devagotchi project license was selected in the supplied source. This packaging adds no license and makes no open-source-license claim. Dependency manifests and locks are included; dependencies themselves are not vendored here.

## Included implementation and planned work

The implementation includes the local Linux broker, durable operation journal, Unix IPC, MCP stdio adapter, native inspector, generated contracts, build inputs, configuration example, icons/capabilities, scripts, and test harness source. The preserved plans describe additional work. Graph execution, trusted-device mesh execution, an authenticated runtime HTTP API, Windows/macOS execution providers, and installers are not implemented by this snapshot. Public reference endpoints are a separate website service and do not grant workstation execution access. Website source is not included in this archive.

## Preservation and package-only files

All copied source code, manifests, lockfiles, schema, configuration, icons, scripts, harnesses, desktop README, and five planning documents are byte-identical to the supplied canonical source at packaging time. The public root README replaces the development archive's root README only inside this ZIP. No canonical file was edited.

The package-only files are `README.md`, `PREVIEW-NOTICE.md`, `verification/README.md`, `SOURCE-SNAPSHOT.json`, and `FILE-MANIFEST.sha256`. `SOURCE-SNAPSHOT.json` identifies these exceptions and a digest of the verbatim file set. It is packaging metadata, not an upstream Git commit or signed provenance attestation.

## Historical evidence and omitted material

No product build, product test, dependency installation, or benchmark was performed while packaging this preview. Archive validation checked safe entry paths, required build inputs, ZIP integrity, per-file checksums, and byte equality with the supplied source. It does not establish that a new visitor's machine can build or run the product.

The original historical verification JSON, build logs, binary hashes, environment reports, screenshots, and source-manifest reports are deliberately omitted. The archive also excludes compiled targets, frontend distribution output, dependencies/caches, Git metadata, broker state, and temporary files. Test fixture source is included as explicitly identified harness code; captured fixture artifacts and runtime data are excluded.

The preserved planning documents and desktop README retain historical statements about development checks and the planning snapshot. They are not newly reproduced evidence. Links from the architecture plan and implementation guide to `verification/README.md` resolve to an omission notice in this preview. References to the parent DesktopCommanderMCP audit, its partial upstream snapshot and reproductions, the pre-planning foundation archive/hash, and historical raw reports refer to separate archival material not included here. The original `075a259e...` archive digest in those documents is not the digest of this public ZIP.

Planning documents also retain the repository-access and website/publication status recorded when authored. This archive does not attest to a GitHub repository's current availability, a website deployment, custom-domain routing, a named MCP host integration, or a public endpoint's live protocol behavior. Graph/mesh schemas and performance budgets in those plans remain proposals unless a later implementation and its evidence establish otherwise.

## Integrity checks

The external `devagotchi-linux-source-preview.sha256` file contains the SHA-256 digest of the ZIP. Run `sha256sum -c devagotchi-linux-source-preview.sha256` beside the ZIP before extraction. From the extracted `devagotchi/` directory, run `sha256sum -c FILE-MANIFEST.sha256` to check every included file other than the manifest itself. The manifest excludes itself to avoid a self-referential checksum. Checksums do not constitute code signing or a release certification.
